function changeHeader(newHeader) {
  document.getElementById("header").innerText = newHeader;
}
